ATÖLYE — ayrı gövde delik planı. Tüm ölçüler mm.

Yalnızca mobilya vidası (konfirmat) için tanımlanmış taşıyıcı gövde levhası birleşimleri. Kapaklar, çekmeceler, sökülebilir raflar, ince arkalıklar, menteşeler ve raylar için otomatik delik açılmaz.

drilling.csv: UTF-8 BOM, ayırıcı ;, ondalık nokta. Her satır bir işlemdir. PART_ID kesim listesindeki Pxxxx koduyla aynıdır. SOURCE_PART_ID uygulama kimliğidir. JOINT_ID aynı vidanın geçiş deliğini, kenar deliğini ve baş yuvasını eşleştirir.

A_MM, B_MM ve THICKNESS_COORD_MM bantsız HAM PARÇADAKİ giriş noktası koordinatlarıdır. Bant ölçü ve payları zaten uygulanmıştır; kenar bandını tekrar düşmeyin. Şemalarda A sağa, B aşağı yönelir; şemayı aynalamayın. Tablo koordinatları kesin konumu verir, semboller şematiktir.

FACE: face-t-min / face-t-max T=0 / T=kalınlık yüzeyleridir; edge-a-min / edge-a-max A+ / A− yönünde kenar girişidir; edge-b-min / edge-b-max B+ / B− yönünde kenar girişidir. Giriş noktası A_MM/B_MM ile belirtilir; şekilli parçada iç oyuk kenarı olabilir. LOCAL_DIRECTION_A/B/T giriş yüzeyinden levhaya doğru delme yönüdür. Kenar deliği belirtilen kenardan açılır, geniş yüzeyden değil.

WORLD_ENTRY_* ve DIRECTION_* dolabın konumu ve dönüşü uygulanmış oda eksenlerini kullanır. Her çizimde A/B/T eksenleri X/Y/Z vektörleriyle belirtilir. Bu sütunlar bağlantı doğrulama içindir; makine koordinatı olarak kullanmayın.

clearance geçiş deliğidir; pilot kenar pilot deliğidir; countersink vida başı yuvasıdır. Boş DEPTH_MM ve REQUIRES_SETUP=1 baş yuvası derinliğinin ve takım profilinin seçilen vidaya göre atölyede belirlenmesi gerektiğini gösterir. İşlemi sıfır derinlikli delik olarak uygulamayın.

Bu dosyalar atölye için işlem listesi ve şemalardır; CNC programı veya donanıma özel evrensel delik planı değildir. Vida çıkıntısını, pilot çapını, baş yuvası derinliğini ve profilini seçilen bağlantı elemanı ve malzemeyle doğrulayın. Ayarlar settings.csv dosyasındadır.

Pxxxx kodu kesim ve delik planında aynıdır; delik şemalarının kendi açıkça işaretli eksenleri vardır. Yönü kesim çiziminden farklı olabilir. Delme işlemlerinde delik şemasının koordinatlarını kullanın. Ölçüler 0,001 mm, CSV vektörleri 12 ondalık basamak hassasiyetindedir; SVG üzerindeki kısa vektörler yalnızca yönü açıklar.

SCREW=7×50 mm; CLEARANCE=7 mm; PILOT=5 mm; PILOT_EXTRA_DEPTH=2 mm; END_OFFSET=50 mm; MAX_SPACING=300 mm; HEAD_SEAT_DIAMETER=10 mm; HEAD_SEAT_DEPTH=UNSET mm.
