Dolap · İstanbul
Takım: AT-51EA0747C212A1DE · Tarih: 2026-10-10 · Sayfa: 1/10

ATÖLYE — ayrı gövde delik planı. Tüm ölçüler mm.

Konfirmat için tanımlanmış taşıyıcı gövde birleşimleri ve MDF arkalık vida bağlantıları. Bindirme 3 mm sert lif arkalıklar çivi listesi alır, otomatik delinmez. Kapaklar, çekmeceler, sökülebilir raflar, menteşeler ve raylar için otomatik delik açılmaz.

drilling.csv: UTF-8 BOM, ayırıcı ;, ondalık nokta. Her satır bir işlemdir. PART_ID kesim listesindeki Pxxxx koduyla aynıdır. SOURCE_PART_ID uygulama kimliğidir. JOINT_ID aynı vidanın geçiş deliğini, kenar deliğini ve baş yuvasını eşleştirir.

A_MM, B_MM ve THICKNESS_COORD_MM bantsız HAM PARÇADAKİ giriş noktası koordinatlarıdır. Bant ölçü ve payları zaten uygulanmıştır; kenar bandını tekrar düşmeyin. Şemalarda A sağa, B aşağı yönelir; şemayı aynalamayın. Tablo koordinatları kesin konumu verir, semboller şematiktir.

FACE: face-t-min / face-t-max T=0 / T=kalınlık yüzeyleridir; edge-a-min / edge-a-max A+ / A− yönünde kenar girişidir; edge-b-min / edge-b-max B+ / B− yönünde kenar girişidir. Giriş noktası A_MM/B_MM ile belirtilir; şekilli parçada iç oyuk kenarı olabilir. LOCAL_DIRECTION_A/B/T giriş yüzeyinden levhaya doğru delme yönüdür. Kenar deliği belirtilen kenardan açılır, geniş yüzeyden değil.

WORLD_ENTRY_* ve DIRECTION_* dolabın konumu ve dönüşü uygulanmış oda eksenlerini kullanır. parts.csv dosyasında A/B/T eksenleri X/Y/Z vektörleriyle belirtilir; şemalarda fiziksel kenarlar ve yüzeyler gösterilir. Bu sütunlar bağlantı doğrulama içindir; makine koordinatı olarak kullanmayın.

clearance geçiş deliğidir; pilot kenar pilot deliğidir; countersink vida başı yuvasıdır. Boş DEPTH_MM ve REQUIRES_SETUP=1 baş yuvası derinliğinin ve takım profilinin seçilen vidaya göre atölyede belirlenmesi gerektiğini gösterir. İşlemi sıfır derinlikli delik olarak uygulamayın.

Bu dosyalar atölye için işlem listesi ve şemalardır; CNC programı veya donanıma özel evrensel delik planı değildir. Vida çıkıntısını, pilot çapını, baş yuvası derinliğini ve profilini seçilen bağlantı elemanı ve malzemeyle doğrulayın. Ayarlar settings.csv dosyasındadır.

Pxxxx kodu kesim ve delik planında aynıdır; delik şemalarının kendi açıkça işaretli eksenleri vardır. Yönü kesim çiziminden farklı olabilir. Delme işlemlerinde delik şemasının koordinatlarını kullanın. Ölçüler 0,001 mm, CSV vektörleri 12 ondalık basamak hassasiyetindedir; bu kayıt hassasiyetidir, üretim toleransı değildir. Her SVG bakış yüzeyini gösterir; delme giriş yüzeyi her işlem için ayrı belirtilir.

FASTENER_TYPE ve SCREW_DIAMETER_MM/SCREW_LENGTH_MM her işlemin bağlantı elemanını belirtir, tüm takımın tek vidasını değil. rear-fastening.csv her arkalığın yöntemini, adedini, bağlantı elemanı ölçülerini ve destek parçalarını verir; çiviler drilling.csv içinde delik satırı oluşturmaz. CONFIRMAT_PROFILE yalnızca gövde birleşimlerine aittir.

Tablo devamı. Parçanın tüm delikleri ilk sayfada gösterilir.

MEASUREMENT_A_MM/B_MM ve şema tabloları seçilen başlangıcı kullanır: RAW bantsız ham parça, FINISHED bantlı bitmiş kenar. A_MM/B_MM, gerçek delikler ve ham makine konturları değişmez.

CONFIRMAT_PROFILE: SCREW=7×50 mm; CLEARANCE=7 mm; PILOT=5 mm; PILOT_EXTRA_DEPTH=2 mm; END_OFFSET=50 mm; MAX_SPACING=300 mm; SCREWS_PER_JOINT=AUTO; HEAD_SEAT_DIAMETER=10 mm; HEAD_SEAT_DEPTH=UNSET mm.
