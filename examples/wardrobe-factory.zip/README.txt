ATÖLYE — kesim siparişi. Tüm ölçüler mm.

cut-list.csv: UTF-8 BOM; ayırıcı ;, ondalık nokta. İlk satır sütun adlarıdır. Yalnızca parçalar, toplam satırı yok. Her satır kimlikli bir parça; QUANTITY adet.

Kesim ölçüleri: CUT_LENGTH_MM ve CUT_WIDTH_MM. Kenar bandı ZATEN DÜŞÜLMÜŞTÜR. İçe aktarmada otomatik bant düşümünü kapatın. INFO_EDGE_* bantlama için bilgi alanıdır; ölçüyü tekrar küçültmez.

Fabrika bitmiş ölçü kabul edip bandı kendisi düşüyorsa CUT_* yerine FINISHED_LENGTH_MM ve FINISHED_WIDTH_MM alanlarını eşleştirin ve bantlamayı onaylayın. Yalnızca bir ölçü çifti kullanın: bitmiş raf 600, bant 1, kesim 599; 598 değil.

LENGTH = B (parça çiziminin yüksekliği); WIDTH = A (genişliği). Ölçüler büyük kenara göre sıralanmaz. GRAIN_AXIS=LENGTH, B yönünü SHEET_LENGTH_MM eksenine sabitler; NONE yönsüz dekor. ROTATABLE=1 ile 90° dönüş serbest, 0 ile yasak.

INFO_EDGE_LENGTH_1/2 SVG sol/sağ kenarları (B boyunca); INFO_EDGE_WIDTH_1/2 üst/alt kenarları (A boyunca). Değer bant kalınlığı mm, 0 bant yok. Şekilli parçada ilgili SVG dosyasına bakın; iç oyuk kenarları bu dört kenara dahil değildir.

materials.csv her malzeme ve gerçek kalınlık için ayrı kod içerir. Kalınlık seçili levhayla aynı olmalıdır. DXF_FILE ve Pxxxx dosyaları listeyle eşleştirir.

dxf/Pxxxx.dxf: tek kapalı ham parça konturu, CUT katmanı, AutoCAD 2000, 1 birim = 1 mm. SVG ile aynı görünüş için Y yansıtılmıştır. DXF içinde ölçülendirme, delik, pay veya freze telafisi yoktur. Adet CSV listesinden alınır; dosya sayısından değil.

parts/Pxxxx.svg: ölçüler ve bantlanacak kenarların çizimleri. assembly.html: montaj görünümleri ve listeler; tarayıcıdan yazdırılabilir / PDF kaydedilebilir. cutting-reference.html ve cutting/sheet-xxx.svg parça yerleşim referansıdır; makine kesim programı değildir.

Bu bir fabrika iş listesidir. Sütun eşleştirme, nihai kesim planı, testere payı, kenar boşlukları ve makine programını fabrika kendi yazılımında belirler. Dikdörtgen kesim, şekilli oyuğun işlenmesini kapsamaz.

Delik planı ve donanımın özel montaj bağlantıları modellenmez. Yan ray boşluğunu ve boyunu, menteşe boşluklarını ve adedini seçilen donanımla kontrol edin. Çekmece tabanı ve arkalık bindirmelidir; bu ölçüleri kanallı tabana veya gizli raylara doğrudan uygulamayın.
