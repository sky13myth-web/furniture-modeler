Takım: AT-64A409181C3E3E09 · Tarih: 2026-10-10 · Sayfa: 1/1
Projedeki tüm dolapların takımı.
Çizim üzerinden ölçmeyin. Yazılı ölçüleri kullanın.
Ölçüler nominaldir. Üretim toleranslarını atölyeyle belirleyin.

ATÖLYE — kesim siparişi. Tüm ölçüler mm.

cut-list.csv: UTF-8 BOM; ayırıcı ;, ondalık nokta. İlk satır sütun adlarıdır. Yalnızca parçalar, toplam satırı yok. Her satır kimlikli bir parça; QUANTITY adet.

kesim-listesi.xlsx: her malzeme, dekor ve kalınlık için ayrı sekme; önce ham en A ve boy B, sonra adet, kod, parça, dolap, dört bant, damar ve şekil. Malzeme ve levha ölçüsü başlıktadır. Levhalar ve Kesim sırası sekmeleri DXF ile aynıdır. kesim-listesi.csv malzeme ve ayrı bitmiş ölçülerle birleşik okunabilir listedir. E1/E2 SVG sol/sağ, E3/E4 üst/alt kenarıdır. Kesim için yalnızca «Ham kesim» sütunlarını kullanın; bitmiş ölçüler kontrol içindir. B boy, A en; değerler büyük kenara göre sıralanmaz. Başlıklar yazdırma dilindedir. cut-list.csv sabit makine sütunlarını korur.

Kesim ölçüleri: CUT_LENGTH_MM ve CUT_WIDTH_MM. Kenar bandı ZATEN DÜŞÜLMÜŞTÜR. İçe aktarmada otomatik bant düşümünü kapatın. INFO_EDGE_* bantlama için bilgi alanıdır; ölçüyü tekrar küçültmez.

Fabrika bitmiş ölçü kabul edip bandı kendisi düşüyorsa CUT_* yerine FINISHED_LENGTH_MM ve FINISHED_WIDTH_MM alanlarını eşleştirin ve bantlamayı onaylayın. Yalnızca bir ölçü çifti kullanın: bitmiş raf 600, bant 1, kesim 599; 598 değil.

LENGTH = B (parça çiziminin yüksekliği); WIDTH = A (genişliği). Ölçüler büyük kenara göre sıralanmaz. GRAIN_AXIS=LENGTH, B yönünü SHEET_LENGTH_MM eksenine sabitler; NONE yönsüz dekor. ROTATABLE=1 ile 90° dönüş serbest, 0 ile yasak.

INFO_EDGE_LENGTH_1/2 SVG sol/sağ kenarları (B boyunca); INFO_EDGE_WIDTH_1/2 üst/alt kenarları (A boyunca). Değer bant kalınlığı mm, 0 bant yok. Şekilli parçada ilgili SVG dosyasına bakın; iç oyuk kenarları bu dört kenara dahil değildir.

materials.csv her malzeme ve gerçek kalınlık için ayrı kod içerir. Kalınlık seçili levhayla aynı olmalıdır. DXF_FILE ve Pxxxx dosyaları listeyle eşleştirir.

dxf/Pxxxx.dxf: tek kapalı ham parça konturu, CUT katmanı, AutoCAD 2000, 1 birim = 1 mm. SVG ile aynı görünüş için Y yansıtılmıştır. DXF içinde ölçülendirme, delik, pay veya freze telafisi yoktur. Adet CSV listesinden alınır; dosya sayısından değil.

dxf/sheets-all.dxf: seçili parçaların malzeme ve kalınlığa göre gerçek levha yerleşimi. Birleşik DXF içinde her Sxxx levhası sağa kaydırılmıştır; dxf/sheets/sheet-xxx.dxf tek levhayı kaydırmadan içerir. Kapalı Sxxx_PART_Pxxxx konturları 1:1 mm ham kesim ölçüleridir; bant zaten düşülmüştür. Sxxx_STOCK, Sxxx_LABELS ve Sxxx_BLANK_Pxxxx bilgi katmanlarıdır, ek kesim konturları değildir. BLANK, şekilli parçanın dikdörtgen ham parçasıdır; iç oyuk dxf/Pxxxx.dxf ile ayrıca işlenir.

sheet-layout.csv: parça koordinatları levhanın sol üstünden, X sağa/Y aşağı; RAW_* ilk A/B ölçülerini, PLACED_* dönüşü dikkate alan ölçüleri verir. cuts/cut-sequence.csv ve cuts/cut-sequence.html: belirtilen başlangıç bölgesinde numaralı geçiş sırası; testere payı SAW_KERF_MM ayrıca belirtilir. Geçiş koordinatları sol üstten bıçak merkez çizgisidir. cuts/cuts-all.dxf ve cuts/sheet-xxx-cuts.dxf CAD görünümü için Y eksenini yansıtır; LINE geçiş eksenidir, STOCK ve LABELS bilgi katmanlarıdır. Bu operatörün kontrol edeceği sıradır, CNC veya G-code programı değildir.

parts/Pxxxx.svg: ölçüler ve bantlanacak kenarların çizimleri. assembly.html: proje genel görünümü; assembly/cabinet-xxx.html: her dolabın ayrıntılı görünümleri, açıklıkları, kapakları ve iç bölmeleri. Tarayıcıdan yazdırılabilir / PDF kaydedilebilir. cutting-reference.html ve cutting/sheet-xxx.svg parça yerleşim referansıdır; makine kesim programı değildir.

Yerleşim ve giyotin kesim sırası proje ayarlarındaki testere payı ve kenar boşluklarıyla hesaplanır. Fabrika sütun eşleştirmesini, sıranın uygunluğunu ve kendi makine programını kontrol eder. Dikdörtgen kesim, şekilli oyuğun işlenmesini kapsamaz.

Konfirmat için isteğe bağlı gövde delik planı ayrı paket olarak indirilir; bu arşive dahil değildir. Seçilen menteşe ve rayların delikleri modellenmez. Yan ray boşluğunu ve boyunu, menteşe boşluklarını ve adedini seçilen donanımla kontrol edin. Çekmece tabanı ve arkalık bindirmelidir; bu ölçüleri kanallı tabana veya gizli raylara doğrudan uygulamayın.
